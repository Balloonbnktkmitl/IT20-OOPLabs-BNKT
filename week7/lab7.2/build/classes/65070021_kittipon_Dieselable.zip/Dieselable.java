/*
 * IG : i_am_bnkt
 */

/**
 *
 * @author BNKT
 */
public interface Dieselable {

    public abstract void startEngine();

    public abstract void stopEngine();
}
