/*
 * IG : i_am_bnkt
 */

/**
 *
 * @author BNKT
 */
public interface Floatable {

    public abstract void fl0at();
}
